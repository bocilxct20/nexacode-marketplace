@blaze

<ui-option-empty class="data-hidden:hidden">
    <div class="flex items-center justify-center h-10">
        <div class="text-sm text-zinc-500 dark:text-zinc-400 font-medium">
            {{ $slot }}
        </div>
    </div>
</ui-option-empty>
