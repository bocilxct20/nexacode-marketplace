{{-- This file exists for backwards compatibility... --}}
<flux:pillbox.option.empty {{ $attributes }}>
    {{ $slot }}
</flux:pillbox.option.empty>